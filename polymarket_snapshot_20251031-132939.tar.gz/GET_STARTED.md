# 🚀 Быстрый старт HashDive Telegram

## ⚠️ ПРОБЛЕМА: Без GUI нельзя войти на сервере

На сервере Ubuntu **без графики** браузер не откроется.

## ✅ РЕШЕНИЕ: Запустить локально, затем перенести сессию

### Шаг 1: Запустить НА ВАШЕМ КОМПЬЮТЕРЕ (macOS)

```bash
# 1. Войти в HashDive через браузер
python3 hashdive_telegram_persistent.py --no-headless

# 2. Войдите в HashDive через Google в открывшемся браузере
# 3. Подождите пока появится "✅ Ready!"
# 4. Нажмите Ctrl+C
```

### Шаг 2: Копировать сохраненную сессию на сервер

```bash
# Сессия сохранилась локально в /tmp/hashdive_chrome_profile
# Скопировать на сервер:
scp -r /tmp/hashdive_chrome_profile ubuntu@84.201.161.90:/tmp/

# Или заархивировать и загрузить:
cd /tmp
tar -czf hashdive_chrome_profile.tar.gz hashdive_chrome_profile
scp hashdive_chrome_profile.tar.gz ubuntu@84.201.161.90:/tmp/
```

### Шаг 3: На сервере распаковать

```bash
ssh ubuntu@84.201.161.90

# Распаковать сессию
cd /tmp
tar -xzf hashdive_chrome_profile.tar.gz

# Теперь можно запускать в headless!
cd /opt/polymarket-bot
source venv/bin/activate
nohup python3 hashdive_telegram_persistent.py > hashdive.log 2>&1 &
```

## 🎯 Альтернатива: Использовать локальную версию

Если у вас всегда открыт компьютер, можете запускать локально:

```bash
# На вашем Mac:
python3 hashdive_telegram_persistent.py

# Сессия сохраняется в /tmp/hashdive_chrome_profile
# Работает каждые 15 минут
# Алерты идут в Telegram канал: -1003285149330
```

## 💡 Что выбираем?

**А) Локально на вашем Mac:**
- ✅ Просто
- ✅ Работает пока компьютер включен
- ✅ Не нужно VNC на сервер

**Б) На сервере через VNC:**
- ✅ Работает 24/7
- ❌ Нужно настроить VNC
- ❌ Сложнее

Какой вариант выбираете?

