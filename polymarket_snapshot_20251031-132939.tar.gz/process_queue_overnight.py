#!/usr/bin/env python3
"""
Process wallet analysis queue overnight
Keeps workers running until queue is empty or max time reached
"""

import os
import time
import logging
from datetime import datetime, timezone
from dotenv import load_dotenv

from wallet_analyzer import WalletAnalyzer, AnalysisConfig
from db import PolymarketDB

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('queue_process_overnight.log')
    ]
)
logger = logging.getLogger(__name__)

def main():
    """Process queue overnight"""
    load_dotenv()
    
    db_path = os.getenv("DB_PATH", "polymarket_notifier.db")
    max_hours = int(os.getenv("QUEUE_PROCESS_MAX_HOURS", "12"))  # Default 12 hours
    
    logger.info("=" * 60)
    logger.info(f"Starting overnight queue processing (max {max_hours} hours)")
    logger.info("=" * 60)
    
    db = PolymarketDB(db_path)
    
    # Initialize analyzer with more workers for faster processing
    config = AnalysisConfig(
        api_max_workers=5,  # Increase workers for overnight processing
        api_timeout_sec=20,
        api_retry_max=6,
        api_retry_base=1.2,
        analysis_ttl_min=180
    )
    
    analyzer = WalletAnalyzer(db, config)
    analyzer.start_workers()
    
    start_time = datetime.now(timezone.utc)
    last_status_time = start_time
    status_interval = 300  # Log status every 5 minutes
    
    try:
        while True:
            # Check elapsed time
            elapsed = (datetime.now(timezone.utc) - start_time).total_seconds() / 3600
            if elapsed >= max_hours:
                logger.info(f"Reached max time limit ({max_hours} hours), stopping")
                break
            
            # Get queue status
            status = analyzer.get_queue_status()
            
            # Log status periodically
            if (datetime.now(timezone.utc) - last_status_time).total_seconds() >= status_interval:
                logger.info(f"[Status] Queue: {status.get('total_jobs', 0)} total, "
                          f"{status.get('pending_jobs', 0)} pending, "
                          f"{status.get('processing_jobs', 0)} processing, "
                          f"Elapsed: {elapsed:.1f}h")
                last_status_time = datetime.now(timezone.utc)
            
            # Check if queue is empty
            if status.get('ready_jobs', 0) == 0 and status.get('processing_jobs', 0) == 0:
                logger.info("Queue is empty, waiting 60 seconds before final check...")
                time.sleep(60)
                
                # Double check
                status = analyzer.get_queue_status()
                if status.get('ready_jobs', 0) == 0 and status.get('processing_jobs', 0) == 0:
                    logger.info("Queue confirmed empty, stopping")
                    break
            
            # Wait before next check
            time.sleep(30)
            
    except KeyboardInterrupt:
        logger.info("Received interrupt signal, stopping...")
    except Exception as e:
        logger.error(f"Error during queue processing: {e}", exc_info=True)
    finally:
        analyzer.stop_workers()
        elapsed = (datetime.now(timezone.utc) - start_time).total_seconds() / 3600
        logger.info("=" * 60)
        logger.info(f"Overnight processing completed. Elapsed: {elapsed:.1f} hours")
        
        # Final status
        status = db.get_queue_stats()
        logger.info(f"Final queue status: {status}")
        logger.info("=" * 60)

if __name__ == "__main__":
    main()

