# HashDive Insiders Scraper

## 📋 Описание

Этот скрипт парсит данные из HashDive Insiders (https://hashdive.com/Insiders) после авторизации с вашим Pro аккаунтом.

## 🚀 Быстрый старт

### Вариант 1: Интерактивный запуск (рекомендуется)

```bash
python3 hashdive_scraper_interactive.py
```

Скрипт попросит ввести:
- Email для HashDive
- Password для HashDive

После этого откроется браузер, где вы сможете:
1. Проверить правильность авторизации
2. Ручной логин, если автоматический не сработает
3. Увидеть процесс парсинга

### Вариант 2: Через переменные окружения

1. Добавьте в ваш `.env` файл:
```bash
HASHDIVE_EMAIL=your_email@example.com
HASHDIVE_PASSWORD=your_password_here
```

2. Запустите:
```bash
python3 hashdive_insiders_authenticated.py
```

## 📊 Что скрипт делает

1. **Открывает браузер** (видимый режим)
2. **Автоматически логинится** с вашими credentials
3. **Переходит на страницу Insiders**
4. **Извлекает данные из таблиц**:
   - Top Whale Trades
   - Top Whale Holders
5. **Сохраняет**:
   - `hashdive_data.json` - извлеченные данные
   - Скриншоты процесса (01_*.png, 02_*.png, etc.)

## 📁 Выходные файлы

После запуска вы получите:

```
hashdive_data.json          # Все извлеченные данные
01_before_login.png         # Страница до логина
02_login_form.png          # Форма логина
03_form_filled.png         # Заполненная форма
04_after_submit.png        # После отправки
05_insiders_page.png       # Страница Insiders
06_final.png              # Финальное состояние
```

## 🔍 Извлекаемые данные

Скрипт парсит следующие данные:

### Top Whale Trades
- Trade ID
- Market
- Price
- Amount ($)
- Position Size

### Top Whale Holders
- Owner Address
- Token ID
- Balance
- Position Value

## ⚠️ Важные замечания

1. **Браузер будет видимым** - вы увидите весь процесс
2. **Автоматический логин может не сработать** - в этом случае есть 30 секунд на ручной логин
3. **Данные сохраняются в JSON** - легко для дальнейшей обработки
4. **Требуется Pro план** - бесплатные аккаунты не получат доступ к данным

## 🛠️ Устранение проблем

### Проблема: "Could not find login button"
**Решение**: Скрипт даст 30 секунд на ручной клик по кнопке логина

### Проблема: "Browser closed too early"
**Решение**: Измените `await asyncio.sleep(10)` на большее значение в конце скрипта

### Проблема: "Data is empty"
**Решение**: 
- Проверьте, что вы действительно на Pro плане
- Проверьте скриншоты 05_insiders_page.png и 06_final.png

## 📝 Пример использования

```bash
$ python3 hashdive_scraper_interactive.py

HashDive Insiders Scraper
============================================================

Email: your@email.com
Password: ********

Loading HashDive login page...
✓ Found and clicked 'Log in' button
✓ Entered email using selector: input[type="email"]
✓ Entered password using selector: input[type="password"]
✓ Clicked submit button using selector: button[type="submit"]

Navigating to Insiders page...
Extracting data...

✅ Scraping completed!
✅ Data saved to hashdive_data.json
```

## 🔐 Безопасность

⚠️ **Важно**: Не коммитьте файл `.env` с вашими credentials в git!

`.env` уже должен быть в `.gitignore`, но убедитесь:
```bash
grep .env .gitignore
```

## 📞 Дальнейшая обработка данных

После получения JSON файла, вы можете использовать данные для:

1. **Анализ крупных сделок**
2. **Трекинг китов** 
3. **Поиск паттернов**
4. **Интеграция с вашим ботом**

Пример работы с данными:
```python
import json

with open('hashdive_data.json') as f:
    data = json.load(f)
    
for table in data['tables']:
    print(f"Table {table['index']}:")
    for row in table['rows']:
        print(row)
```

## 🎯 Что дальше?

После успешного парсинга данных из Insiders, вы можете:

1. Интегрировать эти данные в ваш `polymarket_notifier.py`
2. Добавить мониторинг крупных сделок
3. Создать алерты на основе whale activity
4. Анализировать позиции крупных игроков

## 📈 Интеграция с вашим ботом

Вы можете добавить функцию для периодического парсинга Insiders:

```python
# В polymarket_notifier.py добавить:
async def fetch_whale_insights():
    # Run hashdive scraper and analyze data
    pass
```

Удачного парсинга! 🚀

