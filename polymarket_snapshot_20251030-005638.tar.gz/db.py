"""
SQLite Database Helper Functions for Polymarket Notifier
Handles all database operations for wallets, trades, and alerts
"""

import sqlite3
import json
import hashlib
import logging
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Tuple, Any
from contextlib import contextmanager

logger = logging.getLogger(__name__)

class PolymarketDB:
    def __init__(self, db_path: str = "polymarket_notifier.db"):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Initialize database tables if they don't exist"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Enable WAL mode for better concurrency
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA cache_size=10000")
            cursor.execute("PRAGMA temp_store=MEMORY")
            
            # Wallets table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS wallets(
                    address TEXT PRIMARY KEY,
                    display TEXT,
                    traded_total INTEGER,
                    win_rate REAL,
                    realized_pnl_total REAL,
                    daily_trading_frequency REAL,
                    source TEXT,
                    added_at TEXT,
                    updated_at TEXT
                )
            """)
            
            # Last trades tracking
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS last_trades(
                    address TEXT PRIMARY KEY,
                    last_seen_trade_id TEXT,
                    updated_at TEXT
                )
            """)
            
            # Alerts sent (for deduplication)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS alerts_sent(
                    alert_key TEXT PRIMARY KEY,
                    sent_at TEXT
                )
            """)
            
            # Add new columns if they don't exist (for existing databases)
            try:
                cursor.execute("ALTER TABLE alerts_sent ADD COLUMN condition_id TEXT")
            except sqlite3.OperationalError:
                pass  # Column already exists
            
            try:
                cursor.execute("ALTER TABLE alerts_sent ADD COLUMN outcome_index INTEGER")
            except sqlite3.OperationalError:
                pass  # Column already exists
                
            try:
                cursor.execute("ALTER TABLE alerts_sent ADD COLUMN wallet_count INTEGER")
            except sqlite3.OperationalError:
                pass  # Column already exists
            
            # Rolling buys window
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS rolling_buys(
                    k TEXT PRIMARY KEY,
                    data TEXT,
                    updated_at TEXT
                )
            """)
            
            # Track first entry per wallet per market direction
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS market_trades(
                    wallet TEXT,
                    condition_id TEXT,
                    side TEXT,
                    first_trade_id TEXT,
                    first_ts REAL,
                    PRIMARY KEY (wallet, condition_id, side)
                )
            """)
            
            # Wallet analysis jobs queue
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS wallet_analysis_jobs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    address TEXT NOT NULL,
                    display TEXT,
                    source TEXT,
                    status TEXT DEFAULT 'pending',
                    retry_count INTEGER DEFAULT 0,
                    max_retries INTEGER DEFAULT 6,
                    next_retry_at TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    error_message TEXT,
                    UNIQUE(address)
                )
            """)
            
            # Wallet analysis cache - stores analysis results to avoid re-analyzing
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS wallet_analysis_cache(
                    address TEXT PRIMARY KEY,
                    traded_total INTEGER,
                    win_rate REAL,
                    realized_pnl_total REAL,
                    daily_trading_frequency REAL,
                    analysis_result TEXT,
                    analyzed_at TEXT,
                    expires_at TEXT
                )
            """)
            
            # Create indexes for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_wallets_traded ON wallets(traded_total)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_wallets_winrate ON wallets(win_rate)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_wallets_pnl ON wallets(realized_pnl_total)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_condition ON alerts_sent(condition_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_sent_at ON alerts_sent(sent_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status ON wallet_analysis_jobs(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_jobs_next_retry ON wallet_analysis_jobs(next_retry_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_jobs_address ON wallet_analysis_jobs(address)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_cache_address ON wallet_analysis_cache(address)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_cache_expires ON wallet_analysis_cache(expires_at)")
            
            conn.commit()
            logger.info("Database initialized successfully")
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row  # Enable dict-like access
        try:
            yield conn
        finally:
            conn.close()
    
    def now_iso(self) -> str:
        """Get current UTC timestamp in ISO format"""
        return datetime.now(timezone.utc).isoformat()
    
    def sha(self, s: str) -> str:
        """Generate SHA256 hash of string"""
        return hashlib.sha256(s.encode("utf-8")).hexdigest()
    
    # Wallet operations
    def upsert_wallet(self, address: str, display: str, traded: int, win_rate: float, 
                     pnl_total: float, daily_freq: float, source: str) -> bool:
        """Insert or update wallet information"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    INSERT INTO wallets(address, display, traded_total, win_rate, 
                                     realized_pnl_total, daily_trading_frequency, 
                                     source, added_at, updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(address) DO UPDATE SET
                        display=excluded.display,
                        traded_total=excluded.traded_total,
                        win_rate=excluded.win_rate,
                        realized_pnl_total=excluded.realized_pnl_total,
                        daily_trading_frequency=excluded.daily_trading_frequency,
                        source=excluded.source,
                        updated_at=excluded.updated_at
                """, (address.lower(), display, traded, win_rate, pnl_total, 
                     daily_freq, source, now, now))
                
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error upserting wallet {address}: {e}")
            return False
    
    def get_wallet(self, address: str) -> Optional[Dict[str, Any]]:
        """Get wallet information by address"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM wallets WHERE address = ?", (address.lower(),))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting wallet {address}: {e}")
            return None
    
    def get_tracked_wallets(self, min_trades: int = 20, max_trades: int = 1000,
                          min_win_rate: float = 0.65, max_win_rate: float = 1.0,
                          max_daily_freq: float = 100.0, limit: int = 200) -> List[str]:
        """Get wallets that meet tracking criteria"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT address FROM wallets
                    WHERE traded_total >= ? AND traded_total <= ?
                    AND win_rate > ? AND win_rate < ?
                    AND daily_trading_frequency <= ?
                    ORDER BY realized_pnl_total DESC, traded_total DESC
                    LIMIT ?
                """, (min_trades, max_trades, min_win_rate, max_win_rate, 
                     max_daily_freq, limit))
                
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error getting tracked wallets: {e}")
            return []
    
    def get_wallet_stats(self) -> Dict[str, int]:
        """Get database statistics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                stats = {}
                
                # Total wallets
                cursor.execute("SELECT COUNT(*) FROM wallets")
                stats['total_wallets'] = cursor.fetchone()[0]
                
                # Wallets meeting criteria
                cursor.execute("""
                    SELECT COUNT(*) FROM wallets
                    WHERE traded_total >= 50 AND traded_total <= 1000
                    AND win_rate > 0.65 AND win_rate < 0.99
                    AND daily_trading_frequency <= 10.0
                """)
                stats['tracked_wallets'] = cursor.fetchone()[0]
                
                # Win rate distribution
                cursor.execute("""
                    SELECT 
                        COUNT(CASE WHEN win_rate >= 0.8 THEN 1 END) as high_winrate,
                        COUNT(CASE WHEN win_rate >= 0.7 AND win_rate < 0.8 THEN 1 END) as medium_winrate,
                        COUNT(CASE WHEN win_rate < 0.7 THEN 1 END) as low_winrate
                    FROM wallets
                """)
                row = cursor.fetchone()
                stats['high_winrate'] = row[0]
                stats['medium_winrate'] = row[1]
                stats['low_winrate'] = row[2]
                
                return stats
        except Exception as e:
            logger.error(f"Error getting wallet stats: {e}")
            return {}
    
    def cleanup_old_wallets(self, max_trades: int = 1000, max_wallets: int = 200):
        """Remove wallets that exceed limits"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Remove wallets with too many trades
                cursor.execute("DELETE FROM wallets WHERE traded_total > ?", (max_trades,))
                removed_trades = cursor.rowcount
                
                # Keep only top wallets by PnL
                cursor.execute("""
                    DELETE FROM wallets WHERE address NOT IN (
                        SELECT address FROM wallets
                        WHERE traded_total >= 50 AND traded_total <= ?
                        AND win_rate > 0.65 AND win_rate < 0.99
                        AND daily_trading_frequency <= 10.0
                        ORDER BY realized_pnl_total DESC, traded_total DESC
                        LIMIT ?
                    )
                """, (max_trades, max_wallets))
                removed_limit = cursor.rowcount
                
                conn.commit()
                
                if removed_trades > 0 or removed_limit > 0:
                    logger.info(f"Cleaned up {removed_trades + removed_limit} wallets")
                    
        except Exception as e:
            logger.error(f"Error cleaning up wallets: {e}")
    
    # Trade tracking operations
    def get_last_seen_trade_id(self, address: str) -> Optional[str]:
        """Get last seen trade ID for wallet"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT last_seen_trade_id FROM last_trades WHERE address = ?", 
                             (address.lower(),))
                row = cursor.fetchone()
                return row[0] if row and row[0] else None
        except Exception as e:
            logger.error(f"Error getting last trade ID for {address}: {e}")
            return None
    
    def set_last_seen_trade_id(self, address: str, trade_id: str) -> bool:
        """Set last seen trade ID for wallet"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    INSERT INTO last_trades(address, last_seen_trade_id, updated_at)
                    VALUES(?,?,?)
                    ON CONFLICT(address) DO UPDATE SET
                        last_seen_trade_id=excluded.last_seen_trade_id,
                        updated_at=excluded.updated_at
                """, (address.lower(), trade_id, now))
                
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error setting last trade ID for {address}: {e}")
            return False
    
    # Rolling window operations
    def update_rolling_window(self, condition_id: str, outcome_index: int, 
                            wallet: str, trade_id: str, timestamp: float,
                            window_minutes: float = 10.0, market_title: str = "", 
                            market_slug: str = "", price: float = 0, side: str = "BUY") -> Tuple[str, Dict[str, Any]]:
        """Update rolling window for consensus detection grouped by side"""
        try:
            # Group by side (direction)
            key = self.sha(f"{condition_id}:{outcome_index}:{side}")
            window_start = timestamp - (window_minutes * 60)
            entry = {"wallet": wallet, "trade_id": trade_id, "ts": timestamp, "price": price}
            if market_title:
                entry["marketTitle"] = market_title
            if market_slug:
                entry["marketSlug"] = market_slug
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT data FROM rolling_buys WHERE k = ?", (key,))
                row = cursor.fetchone()
                
                if not row:
                    obj = {"events": [entry], "first_ts": timestamp, "last_ts": timestamp}
                else:
                    obj = json.loads(row[0])
                    # Remove stale events
                    obj["events"] = [e for e in obj.get("events", []) if e["ts"] >= window_start]
                    # Add new event
                    obj["events"].append(entry)
                    # Deduplicate wallets (keep latest per wallet)
                    obj["events"] = self._dedupe_wallets(obj["events"])
                    # Update timestamps
                    if obj["events"]:
                        obj["first_ts"] = min(e["ts"] for e in obj["events"])
                        obj["last_ts"] = max(e["ts"] for e in obj["events"])
                
                cursor.execute("""
                    INSERT INTO rolling_buys(k, data, updated_at)
                    VALUES(?,?,?)
                    ON CONFLICT(k) DO UPDATE SET 
                        data=excluded.data, 
                        updated_at=excluded.updated_at
                """, (key, json.dumps(obj), self.now_iso()))
                
                conn.commit()
                return key, obj
                
        except Exception as e:
            logger.error(f"Error updating rolling window: {e}")
            return "", {}
    
    def _dedupe_wallets(self, events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Keep latest event per wallet"""
        by_wallet = {}
        for e in events:
            w = e["wallet"]
            if w not in by_wallet or e["ts"] > by_wallet[w]["ts"]:
                by_wallet[w] = e
        return list(by_wallet.values())
    
    # Alert operations
    def has_traded_market(self, wallet: str, condition_id: str, side: str) -> bool:
        """Check if wallet has already traded this market in this direction"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT 1 FROM market_trades 
                    WHERE wallet = ? AND condition_id = ? AND side = ?
                """, (wallet, condition_id, side))
                return cursor.fetchone() is not None
        except Exception as e:
            logger.error(f"Error checking market trade: {e}")
            return False
    
    def mark_market_traded(self, wallet: str, condition_id: str, side: str, timestamp: float):
        """Mark wallet as having traded this market in this direction"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO market_trades(wallet, condition_id, side, first_ts)
                    VALUES(?, ?, ?, ?)
                """, (wallet, condition_id, side, timestamp))
                conn.commit()
        except Exception as e:
            logger.error(f"Error marking market trade: {e}")
    
    def is_alert_sent(self, condition_id: str, outcome_index: int, 
                     first_ts: float, last_ts: float, alert_key: str = "") -> bool:
        """Check if alert was already sent for this consensus"""
        try:
            if alert_key:
                key = self.sha(f"ALERT:{alert_key}:{int(first_ts)}:{int(last_ts)}")
            else:
                key = self.sha(f"ALERT:{condition_id}:{outcome_index}:{int(first_ts)}:{int(last_ts)}")
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT 1 FROM alerts_sent WHERE alert_key = ?", (key,))
                return cursor.fetchone() is not None
                
        except Exception as e:
            logger.error(f"Error checking alert status: {e}")
            return False
    
    def mark_alert_sent(self, condition_id: str, outcome_index: int, 
                       wallet_count: int, first_ts: float, last_ts: float, alert_key: str = "") -> bool:
        """Mark alert as sent"""
        try:
            if alert_key:
                key = self.sha(f"ALERT:{alert_key}:{int(first_ts)}:{int(last_ts)}")
            else:
                key = self.sha(f"ALERT:{condition_id}:{outcome_index}:{int(first_ts)}:{int(last_ts)}")
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO alerts_sent(alert_key, sent_at, condition_id, 
                                          outcome_index, wallet_count)
                    VALUES(?,?,?,?,?)
                """, (key, self.now_iso(), condition_id, outcome_index, wallet_count))
                
                conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"Error marking alert as sent: {e}")
            return False
    
    def cleanup_old_data(self, days_to_keep: int = 7):
        """Clean up old data to prevent database bloat"""
        try:
            cutoff_date = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            cutoff_date = cutoff_date.replace(day=cutoff_date.day - days_to_keep)
            cutoff_iso = cutoff_date.isoformat()
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Clean old alerts
                cursor.execute("DELETE FROM alerts_sent WHERE sent_at < ?", (cutoff_iso,))
                alerts_removed = cursor.rowcount
                
                # Clean old rolling buys (keep only recent ones)
                cursor.execute("DELETE FROM rolling_buys WHERE updated_at < ?", (cutoff_iso,))
                rolling_removed = cursor.rowcount
                
                conn.commit()
                
                if alerts_removed > 0 or rolling_removed > 0:
                    logger.info(f"Cleaned up {alerts_removed} old alerts and {rolling_removed} old rolling buys")
                    
        except Exception as e:
            logger.error(f"Error cleaning up old data: {e}")
    
    # Wallet analysis jobs queue operations
    def add_wallet_to_queue(self, address: str, display: str = None, source: str = None) -> bool:
        """Add wallet to analysis queue"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    INSERT OR IGNORE INTO wallet_analysis_jobs(
                        address, display, source, status, created_at, updated_at
                    )
                    VALUES(?,?,?,?,?,?)
                """, (address.lower(), display, source, 'pending', now, now))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error adding wallet to queue {address}: {e}")
            return False
    
    def get_pending_jobs(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get pending jobs ready for processing"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    SELECT * FROM wallet_analysis_jobs
                    WHERE status = 'pending' 
                    AND (next_retry_at IS NULL OR next_retry_at <= ?)
                    ORDER BY created_at ASC
                    LIMIT ?
                """, (now, limit))
                
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting pending jobs: {e}")
            return []
    
    def claim_job(self, job_id: int) -> bool:
        """Atomically claim a job for processing"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                # Try to claim the job by updating status to 'processing'
                cursor.execute("""
                    UPDATE wallet_analysis_jobs
                    SET status = 'processing', updated_at = ?
                    WHERE id = ? AND status = 'pending'
                """, (now, job_id))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error claiming job {job_id}: {e}")
            return False
    
    def update_job_status(self, job_id: int, status: str, error_message: str = None, 
                         next_retry_at: str = None) -> bool:
        """Update job status"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    UPDATE wallet_analysis_jobs
                    SET status = ?, error_message = ?, next_retry_at = ?, updated_at = ?
                    WHERE id = ?
                """, (status, error_message, next_retry_at, now, job_id))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error updating job status {job_id}: {e}")
            return False
    
    def increment_job_retry(self, job_id: int, next_retry_at: str, error_message: str = None) -> bool:
        """Increment retry count and set next retry time"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    UPDATE wallet_analysis_jobs
                    SET retry_count = retry_count + 1,
                        next_retry_at = ?,
                        error_message = ?,
                        updated_at = ?
                    WHERE id = ?
                """, (next_retry_at, error_message, now, job_id))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error incrementing job retry {job_id}: {e}")
            return False
    
    def complete_job(self, job_id: int) -> bool:
        """Mark job as completed and remove from queue"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM wallet_analysis_jobs WHERE id = ?", (job_id,))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error completing job {job_id}: {e}")
            return False
    
    def get_queue_stats(self) -> Dict[str, int]:
        """Get queue statistics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                stats = {}
                
                # Count by status
                cursor.execute("""
                    SELECT status, COUNT(*) FROM wallet_analysis_jobs
                    GROUP BY status
                """)
                
                for row in cursor.fetchall():
                    stats[f"{row[0]}_jobs"] = row[1]
                
                # Total jobs
                cursor.execute("SELECT COUNT(*) FROM wallet_analysis_jobs")
                stats['total_jobs'] = cursor.fetchone()[0]
                
                # Jobs ready for retry
                now = self.now_iso()
                cursor.execute("""
                    SELECT COUNT(*) FROM wallet_analysis_jobs
                    WHERE status = 'pending' 
                    AND (next_retry_at IS NULL OR next_retry_at <= ?)
                """, (now,))
                stats['ready_jobs'] = cursor.fetchone()[0]
                
                return stats
        except Exception as e:
            logger.error(f"Error getting queue stats: {e}")
            return {}
    
    # Wallet analysis cache operations
    def get_cached_analysis(self, address: str) -> Optional[Dict[str, Any]]:
        """Get cached analysis result for wallet"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("""
                    SELECT * FROM wallet_analysis_cache
                    WHERE address = ? AND expires_at > ?
                """, (address.lower(), now))
                
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting cached analysis for {address}: {e}")
            return None
    
    def cache_analysis_result(self, address: str, traded_total: int, win_rate: float,
                             realized_pnl_total: float, daily_frequency: float,
                             analysis_result: str, ttl_hours: int = 24) -> bool:
        """Cache analysis result for wallet"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = datetime.now(timezone.utc)
                expires_at = now + timedelta(hours=ttl_hours)
                
                cursor.execute("""
                    INSERT OR REPLACE INTO wallet_analysis_cache(
                        address, traded_total, win_rate, realized_pnl_total,
                        daily_trading_frequency, analysis_result, analyzed_at, expires_at
                    )
                    VALUES(?,?,?,?,?,?,?,?)
                """, (address.lower(), traded_total, win_rate, realized_pnl_total,
                     daily_frequency, analysis_result, now.isoformat(), expires_at.isoformat()))
                
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error caching analysis result for {address}: {e}")
            return False
    
    def cleanup_expired_cache(self) -> int:
        """Remove expired cache entries"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                now = self.now_iso()
                
                cursor.execute("DELETE FROM wallet_analysis_cache WHERE expires_at <= ?", (now,))
                removed_count = cursor.rowcount
                
                conn.commit()
                
                if removed_count > 0:
                    logger.info(f"Cleaned up {removed_count} expired cache entries")
                
                return removed_count
        except Exception as e:
            logger.error(f"Error cleaning up expired cache: {e}")
            return 0

# Example usage and testing
    def get_tracked_wallet_addresses(self) -> List[str]:
        """Get list of tracked wallet addresses"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT address FROM wallets ORDER BY realized_pnl_total DESC")
                addresses = [row[0] for row in cursor.fetchall()]
                return addresses
        except Exception as e:
            logger.error(f"Error getting tracked wallet addresses: {e}")
            return []

if __name__ == "__main__":
    # Test database operations
    db = PolymarketDB("test_polymarket.db")
    
    # Test wallet operations
    db.upsert_wallet("0x123", "Test Wallet", 100, 0.75, 1000.0, 2.5, "test")
    wallet = db.get_wallet("0x123")
    print(f"Retrieved wallet: {wallet}")
    
    # Test stats
    stats = db.get_wallet_stats()
    print(f"Database stats: {stats}")
    
    # Cleanup
    import os
    os.remove("test_polymarket.db")
