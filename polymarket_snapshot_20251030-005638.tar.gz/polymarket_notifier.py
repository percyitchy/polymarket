"""
Polymarket Notifier Bot - Main Script
Monitors high-performing Polymarket wallets for consensus buy signals
"""

import os
import time
import asyncio
import logging
import threading
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_exponential

# Import our modules
try:
    from fetch_leaderboards import scrape_polymarket_leaderboards
    PLAYWRIGHT_AVAILABLE = True
    print("Using Playwright scraper")
except Exception as e:
    print(f"Playwright not available: {e}")
    from fetch_leaderboards_enhanced import scrape_polymarket_leaderboards_enhanced as scrape_polymarket_leaderboards
    PLAYWRIGHT_AVAILABLE = False

from db import PolymarketDB
from notify import TelegramNotifier
from wallet_analyzer import WalletAnalyzer, AnalysisConfig
from bet_monitor import BetDetector, TelegramNotifier as BetTelegramNotifier

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('polymarket_notifier.log')
    ]
)
logger = logging.getLogger(__name__)

class PolymarketNotifier:
    def __init__(self):
        # Configuration from environment
        self.telegram_token = os.getenv("TELEGRAM_BOT_TOKEN")
        self.telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID")
        self.poll_interval = int(os.getenv("POLL_INTERVAL_SEC", "7"))
        self.alert_window_min = float(os.getenv("ALERT_WINDOW_MIN", "15"))
        self.min_consensus = int(os.getenv("MIN_CONSENSUS", "3"))  # Minimum 3 wallets required
        if self.min_consensus < 3:
            logger.warning(f"min_consensus is {self.min_consensus}, forcing to 3")
            self.min_consensus = 3
        self.max_wallets = int(os.getenv("MAX_WALLETS", "200"))
        self.max_predictions = int(os.getenv("MAX_PREDICTIONS", "1000"))
        self.db_path = os.getenv("DB_PATH", "polymarket_notifier.db")
        
        # Analysis queue configuration
        self.api_max_workers = int(os.getenv("API_MAX_WORKERS", "3"))
        self.api_timeout_sec = int(os.getenv("API_TIMEOUT_SEC", "20"))
        self.api_retry_max = int(os.getenv("API_RETRY_MAX", "6"))
        self.api_retry_base = float(os.getenv("API_RETRY_BASE", "1.2"))
        self.analysis_ttl_min = int(os.getenv("ANALYSIS_TTL_MIN", "180"))
        
        # Leaderboard URLs to scrape
        self.leaderboard_urls = [
            "https://polymarket.com/leaderboard/overall/today/profit",
            "https://polymarket.com/leaderboard/overall/weekly/profit",
            "https://polymarket.com/leaderboard/overall/monthly/profit"
        ]
        
        # Initialize components
        self.db = PolymarketDB(self.db_path)
        self.notifier = TelegramNotifier(self.telegram_token, self.telegram_chat_id)
        self.bet_detector = BetDetector(self.db_path)
        
        # Initialize wallet analyzer
        analysis_config = AnalysisConfig(
            api_max_workers=self.api_max_workers,
            api_timeout_sec=self.api_timeout_sec,
            api_retry_max=self.api_retry_max,
            api_retry_base=self.api_retry_base,
            analysis_ttl_min=self.analysis_ttl_min
        )
        self.wallet_analyzer = WalletAnalyzer(self.db, analysis_config)
        
        # Polymarket Data API endpoints
        self.data_api = "https://data-api.polymarket.com"
        self.trades_endpoint = f"{self.data_api}/trades"
        self.closed_positions_endpoint = f"{self.data_api}/closed-positions"
        self.traded_endpoint = f"{self.data_api}/traded"
        
        # Headers for API requests
        self.headers = {
            "User-Agent": "PolymarketNotifier/1.0 (+https://polymarket.com)"
        }
        
        # Monitoring state
        self.monitoring = False
        self.loop_count = 0
        
    def validate_config(self) -> bool:
        """Validate configuration and environment variables"""
        if not self.telegram_token or not self.telegram_chat_id:
            logger.error("TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID must be set in .env file")
            return False
        
        logger.info("Configuration validated successfully")
        return True
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
    def http_get(self, url: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Make HTTP GET request with retry logic"""
        import requests
        
        response = requests.get(url, params=params, headers=self.headers, timeout=20)
        response.raise_for_status()
        return response
    
    async def collect_wallets_from_leaderboards(self) -> Dict[str, Dict[str, str]]:
        """Collect wallet addresses from Polymarket APIs"""
        logger.info("Starting wallet collection from Polymarket APIs...")
        
        try:
            # Use official API scraper for maximum wallet collection
            logger.info("Using official Polymarket API scraper")
            from api_scraper import PolymarketAPIScraper
            
            async with PolymarketAPIScraper() as scraper:
                wallet_addresses = await scraper.scrape_all_wallets()
            
            # Convert to expected format
            wallets = {}
            for addr in wallet_addresses:
                wallets[addr] = {
                    "display": addr,
                    "source": "polymarket_api"
                }
            
            logger.info(f"Collected {len(wallets)} unique wallets from APIs")
            return wallets
        except Exception as e:
            logger.error(f"Error collecting wallets from APIs: {e}")
            # Fallback to Playwright if API fails
            try:
                if PLAYWRIGHT_AVAILABLE:
                    logger.info("Falling back to Playwright scraper")
                    wallets = await scrape_polymarket_leaderboards(
                        self.leaderboard_urls,
                        headless=True
                    )
                else:
                    logger.info("Falling back to enhanced requests scraper")
                    from fetch_leaderboards_enhanced import scrape_polymarket_leaderboards_enhanced
                    wallets = scrape_polymarket_leaderboards_enhanced(
                        self.leaderboard_urls,
                        max_pages_per_url=40
                    )
                
                logger.info(f"Fallback collected {len(wallets)} unique wallets")
                return wallets
            except Exception as fallback_error:
                logger.error(f"Fallback also failed: {fallback_error}")
                return {}
    
    
    def analyze_and_filter_wallets(self, wallets: Dict[str, Dict[str, str]]) -> int:
        """Add wallets to analysis queue instead of analyzing directly"""
        logger.info(f"Adding {len(wallets)} wallets to analysis queue...")
        
        # Add wallets to queue
        added_count = self.wallet_analyzer.add_wallets_to_queue(wallets)
        
        # Get queue status
        queue_status = self.wallet_analyzer.get_queue_status()
        
        logger.info(f"Added {added_count} wallets to queue. Queue status: {queue_status}")
        
        # Send summary notification
        self.notifier.send_wallet_collection_summary(
            len(wallets), added_count, {"method": "queue_based"}
        )
        
        return added_count
    
    def get_new_buys(self, address: str, last_seen_trade_id: Optional[str]) -> tuple[List[Dict[str, Any]], Optional[str]]:
        """Get new buy trades for a wallet"""
        try:
            params = {"user": address, "side": "BUY", "limit": 50}
            response = self.http_get(self.trades_endpoint, params=params)
            trades = response.json() if response.ok else []
            
            new_events = []
            newest_id = last_seen_trade_id
            
            for trade in trades:
                trade_id = str(trade.get("id") or trade.get("tradeId") or 
                             trade.get("_id") or trade.get("transactionHash") or "")
                
                if not trade_id:
                    continue
                
                if last_seen_trade_id and trade_id == last_seen_trade_id:
                    break
                
                condition_id = trade.get("conditionId") or trade.get("market") or trade.get("marketId")
                outcome_index = trade.get("outcomeIndex")
                
                if not condition_id or outcome_index is None:
                    continue
                
                timestamp = trade.get("timestamp") or trade.get("createdAt")
                if isinstance(timestamp, str):
                    try:
                        timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).timestamp()
                    except Exception:
                        timestamp = time.time()
                elif timestamp is None:
                    timestamp = time.time()
                
                # Extract price
                price = float(trade.get("price", 0))
                
                # Extract side (BUY/SELL)
                side = trade.get("side", "BUY")
                
                # Try to extract market title and slug from trade
                # Data API uses 'title' and 'slug' fields
                market_title = trade.get("title") or trade.get("question") or ""
                market_slug = trade.get("slug") or trade.get("eventSlug") or ""
                
                # If we don't have slug, fetch it from CLOB API
                if not market_slug and condition_id:
                    try:
                        import requests
                        slug_url = f"https://clob.polymarket.com/markets/{condition_id}"
                        slug_resp = requests.get(slug_url, timeout=3)
                        if slug_resp.status_code == 200:
                            slug_data = slug_resp.json()
                            market_slug = slug_data.get('market_slug') or slug_data.get('slug') or ""
                            if not market_title:
                                market_title = slug_data.get('question') or slug_data.get('title') or ""
                    except Exception:
                        pass  # Silently fail, will retry later
                
                new_events.append({
                    "trade_id": trade_id,
                    "conditionId": condition_id,
                    "outcomeIndex": int(outcome_index),
                    "timestamp": float(timestamp),
                    "marketTitle": market_title,  # Store title for alerts
                    "marketSlug": market_slug,  # Store slug for URL
                    "price": price,  # Store entry price
                    "side": side  # Store direction
                })
                
                if newest_id is None:
                    newest_id = trade_id
            
            # Update newest_id to first trade's id if any
            if trades:
                top_trade_id = str(trades[0].get("id") or trades[0].get("tradeId") or 
                                 trades[0].get("_id") or trades[0].get("transactionHash") or newest_id or "")
                if top_trade_id:
                    newest_id = top_trade_id
            
            return new_events, newest_id
            
        except Exception as e:
            logger.warning(f"Error getting new buys for {address}: {e}")
            return [], last_seen_trade_id
    
    def check_consensus_and_alert(self, condition_id: str, outcome_index: int, 
                                 wallet: str, trade_id: str, timestamp: float, 
                                 price: float = 0, side: str = "BUY", 
                                 market_title: str = "", market_slug: str = ""):
        """Check for consensus and send alert if threshold met"""
        try:
            # Check if this is first entry for this wallet in this market direction
            if self.db.has_traded_market(wallet, condition_id, side):
                logger.debug(f"Skipping {wallet}: already traded {condition_id} ({side})")
                return
            
            # Mark this market as traded for this wallet
            self.db.mark_market_traded(wallet, condition_id, side, timestamp)
            
            # Update rolling window grouped by direction
            key, window_data = self.db.update_rolling_window(
                condition_id, outcome_index, wallet, trade_id, timestamp, 
                self.alert_window_min, market_title, market_slug, price, side
            )
            
            # Get unique wallets in window for this direction
            wallets_in_window = sorted({e["wallet"] for e in window_data.get("events", [])})
            
            if len(wallets_in_window) < self.min_consensus:
                return
            
            # Check if alert already sent for this direction
            alert_key = f"{condition_id}:{outcome_index}:{side}"
            if self.db.is_alert_sent(condition_id, outcome_index, 
                                    window_data["first_ts"], window_data["last_ts"], alert_key):
                return
            
            # Extract market info and prices from window events
            market_title = ""
            market_slug = ""
            wallet_prices = {}  # Map wallet -> price
            
            for event in window_data.get("events", []):
                if event.get("marketTitle"):
                    market_title = event["marketTitle"]
                if event.get("marketSlug"):
                    market_slug = event["marketSlug"]
                if event.get("price") and event.get("wallet"):
                    wallet_prices[event["wallet"]] = event.get("price", 0)
            
            # Send alert with prices
            alert_id = key[:8]
            success = self.notifier.send_consensus_alert(
                condition_id, outcome_index, wallets_in_window, wallet_prices,
                self.alert_window_min, self.min_consensus, alert_id, market_title, market_slug, side
            )
            
            if success:
                # Mark alert as sent
                self.db.mark_alert_sent(
                    condition_id, outcome_index, len(wallets_in_window),
                    window_data["first_ts"], window_data["last_ts"], alert_key
                )
                logger.info(f"Sent consensus alert for {condition_id}:{outcome_index} "
                           f"({len(wallets_in_window)} wallets)")
            
        except Exception as e:
            logger.error(f"Error checking consensus: {e}")
    
    def monitor_wallets(self):
        """Main monitoring loop"""
        logger.info("Starting wallet monitoring...")
        self.monitoring = True
        
        while self.monitoring:
            try:
                # Get tracked wallets - strict criteria: 75%+ win rate
                wallets = self.db.get_tracked_wallets(
                    min_trades=10, max_trades=self.max_predictions,
                    min_win_rate=0.75, max_win_rate=1.0,  # Increased to 75%
                    max_daily_freq=100.0, limit=self.max_wallets
                )
                
                if not wallets:
                    logger.warning("No wallets to monitor")
                    time.sleep(self.poll_interval)
                    continue
                
                self.loop_count += 1
                
                # Send heartbeat every 10 loops (every ~70 seconds with 7s poll interval)
                if self.loop_count % 10 == 0:
                    stats = self.db.get_wallet_stats()
                    queue_stats = self.wallet_analyzer.get_queue_status()
                    logger.info(f"Monitoring {len(wallets)} wallets, loop #{self.loop_count}")
                    logger.info(f"Queue status: {queue_stats}")
                    self.notifier.send_heartbeat(stats)
                
                # Heartbeat log every 30 seconds (every ~4 loops with 7s poll interval)
                if self.loop_count % 4 == 0:
                    stats = self.db.get_wallet_stats()
                    queue_stats = self.wallet_analyzer.get_queue_status()
                    now_iso = datetime.now(timezone.utc).isoformat()
                    
                    # Format: [HB] queue=447 analyzed=129 wallets=74 time=2025-01-01T12:01:33Z
                    queue_total = queue_stats.get('total_jobs', 0)
                    analyzed_count = stats.get('total_wallets', 0)
                    tracked_wallets = stats.get('tracked_wallets', 0)
                    
                    logger.info(f"[HB] queue={queue_total} analyzed={analyzed_count} wallets={tracked_wallets} time={now_iso}")
                
                # Collect new wallets from leaderboard if needed (every 20 loops)
                if self.loop_count % 20 == 0:
                    current_wallets = self.db.get_tracked_wallets(min_trades=10, max_trades=1000, min_win_rate=0.75, max_win_rate=1.0, max_daily_freq=100.0, limit=200)
                    if len(current_wallets) < 200:
                        logger.info(f"Only {len(current_wallets)} wallets, collecting more...")
                        wallets_dict = asyncio.run(self.collect_wallets_from_leaderboards())
                        self.analyze_and_filter_wallets(wallets_dict)
                
                # Clean up old wallets every 50 loops
                if self.loop_count % 50 == 0:
                    self.db.cleanup_old_wallets(self.max_predictions, self.max_wallets)
                
                # Clean up expired cache every 100 loops
                if self.loop_count % 100 == 0:
                    cleaned = self.db.cleanup_expired_cache()
                    if cleaned > 0:
                        logger.info(f"Cleaned up {cleaned} expired cache entries")
                
                # Monitor each wallet
                for wallet in wallets:
                    try:
                        last_trade_id = self.db.get_last_seen_trade_id(wallet)
                        new_events, newest_id = self.get_new_buys(wallet, last_trade_id)
                        
                        if new_events:
                            logger.info(f"{wallet}: {len(new_events)} new events")
                        
                        # Process each new event
                        for event in new_events:
                            market_title = event.get("marketTitle", "")
                            market_slug = event.get("marketSlug", "")
                            price = event.get("price", 0)
                            side = event.get("side", "BUY")
                            self.check_consensus_and_alert(
                                event["conditionId"], event["outcomeIndex"],
                                wallet, event["trade_id"], event["timestamp"], 
                                price, side, market_title, market_slug
                            )
                        
                        # Update last seen trade ID
                        if newest_id and newest_id != last_trade_id:
                            self.db.set_last_seen_trade_id(wallet, newest_id)
                        
                        # Spread load across wallets
                        time.sleep(max(0.0, self.poll_interval / max(1, len(wallets))))
                        
                    except Exception as e:
                        logger.error(f"Error monitoring wallet {wallet}: {e}")
                        continue
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(self.poll_interval)
    
    def stop_monitoring(self):
        """Stop the monitoring loop"""
        self.monitoring = False
        logger.info("Monitoring stopped")
    
    async def start_bet_monitoring(self):
        """Start bet monitoring in background"""
        logger.info("Starting bet monitoring...")
        
        # Get wallet addresses from database
        wallet_addresses = self.db.get_tracked_wallet_addresses()
        logger.info(f"Monitoring {len(wallet_addresses)} wallets for matching bets")
        
        # Initialize Telegram notifier for bet alerts
        bet_telegram_notifier = BetTelegramNotifier(self.telegram_token, self.telegram_chat_id)
        
        # Start monitoring in background task
        monitoring_task = asyncio.create_task(
            self.bet_detector.monitor_wallets(wallet_addresses, bet_telegram_notifier)
        )
        
        return monitoring_task

    async def run(self):
        """Main run method"""
        logger.info("Starting Polymarket Notifier Bot...")
        
        # Validate configuration
        if not self.validate_config():
            return
        
        # Test Telegram connection (skip if failed)
        if not self.notifier.test_connection():
            logger.warning("Telegram connection test failed - continuing without Telegram notifications")
            # Don't return, continue with wallet collection
        
        # Start wallet analyzer workers
        self.wallet_analyzer.start_workers()
        
        # Start bet monitoring
        bet_monitoring_task = await self.start_bet_monitoring()
        
        # Send startup notification
        stats = self.db.get_wallet_stats()
        queue_stats = self.wallet_analyzer.get_queue_status()
        self.notifier.send_startup_notification(
            stats.get('total_wallets', 0),
            stats.get('tracked_wallets', 0)
        )
        
        # Collect wallets from leaderboards
        wallets = await self.collect_wallets_from_leaderboards()
        if wallets:
            self.analyze_and_filter_wallets(wallets)
        
        # Start monitoring
        try:
            self.monitor_wallets()
        except KeyboardInterrupt:
            logger.info("Received interrupt signal, stopping...")
            self.stop_monitoring()
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            self.notifier.send_error_notification("System Error", str(e))
        finally:
            # Stop wallet analyzer workers
            self.wallet_analyzer.stop_workers()
            # Cancel bet monitoring task
            bet_monitoring_task.cancel()

def main():
    """Main entry point"""
    notifier = PolymarketNotifier()
    
    try:
        asyncio.run(notifier.run())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")

if __name__ == "__main__":
    main()