# Инструкция по парсингу HashDive Insiders

## 🎯 Что это?

Скрипт для парсинга данных с страницы HashDive Insiders (крупные сделки и холдеры).

## 📋 Требования

- ✅ Pro план на HashDive (у вас есть)
- ✅ Google аккаунт для входа
- ✅ Python 3
- ✅ Playwright (уже установлен)

## 🚀 Запуск

```bash
python3 hashdive_scraper_oauth.py
```

## 📝 Что будет происходить:

1. Откроется браузер Chrome
2. Перейдет на https://hashdive.com
3. **ОСТАНОВИТСЯ** и попросит вас нажать Enter
4. После нажатия Enter:
   - Если вы не залогинены → увидите сообщение "ВЫ НЕ ЗАЛОГИНЕНЫ"
   - Если залогинены → автоматически перейдет на Insiders
5. Скрипт даст **60 секунд** на ручной логин (если нужно)
6. После логина автоматически соберет данные
7. Сохранит результат в `hashdive_data_YYYYMMDD_HHMMSS.json`

## 💾 Результаты

После выполнения вы получите:

```
hashdive_data_20251027_015000.json  # Данные в JSON
01_page_loaded.png                  # Скриншот загрузки
02_after_manual_login.png           # После логина
03_insiders_page.png                # Страница Insiders
04_final_extraction.png             # Финальный результат
```

## ⚠️ Важно!

- **НЕ ЗАКРЫВАЙТЕ** браузер во время работы скрипта
- Если видите "Free period ended" - значит нужен Pro план
- Браузер останется открытым 30 секунд в конце для проверки

## 🔍 Что парсится?

### Top Whale Trades
Данные о крупных сделках:
- Market (рынок)
- Price (цена)
- Amount (сумма)
- Position Size (размер позиции)

### Top Whale Holders
Данные о крупных холдерах:
- Owner (владелец)
- Token ID
- Balance (баланс)
- Position Value (стоимость позиции)

## ❓ Проблемы?

### "Free period ended"
**Решение**: Убедитесь, что у вас есть Pro план

### Браузер закрылся слишком быстро
**Решение**: В коде увеличьте значение `await asyncio.sleep(30)` на большее

### Данные пустые
**Решение**: 
1. Проверьте скриншот `03_insiders_page.png`
2. Убедитесь, что данные загрузились
3. Возможно, на странице нет данных (она пустая)

## 📊 Пример работы с данными

После получения JSON:

```python
import json

with open('hashdive_data_20251027_015000.json', 'r') as f:
    data = json.load(f)

# Посмотреть таблицы
for table in data['tables']:
    print(f"Table {table['index']}: {len(table['rows'])} rows")
    for row in table['rows'][:3]:  # Первые 3 строки
        print(row)
```

## 🎯 Готово!

Теперь можете запускать:

```bash
python3 hashdive_scraper_oauth.py
```

Удачи! 🚀

