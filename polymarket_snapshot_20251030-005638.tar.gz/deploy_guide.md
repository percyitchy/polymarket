# 🚀 Деплой бота на сервер 24/7

## 📋 Быстрая инструкция

### 1. Загрузить файлы на сервер

```bash
# На локальной машине (в папке проекта)
chmod +x upload.sh
./upload.sh
```

### 2. Подключиться к серверу

```bash
ssh ubuntu@84.201.161.90
```

### 3. Запустить деплой

```bash
cd /opt/polymarket-bot
chmod +x deploy.sh
./deploy.sh
```

### 4. Запустить бота

```bash
sudo systemctl start polymarket-bot
sudo systemctl status polymarket-bot
```

## ⚙️ Управление сервисом

| Команда | Описание |
|---------|----------|
| `sudo systemctl start polymarket-bot` | Запустить бота |
| `sudo systemctl stop polymarket-bot` | Остановить бота |
| `sudo systemctl restart polymarket-bot` | Перезапустить бота |
| `sudo systemctl status polymarket-bot` | Статус бота |
| `sudo journalctl -u polymarket-bot -f` | Логи в реальном времени |

## 📊 Мониторинг

### Посмотреть логи:
```bash
sudo journalctl -u polymarket-bot -f
```

### Проверить статус:
```bash
sudo systemctl status polymarket-bot
```

## ✅ Файлы для загрузки

Обязательные файлы (загружаются автоматически через upload.sh):
- `polymarket_notifier.py` - основной бот
- `wallet_analyzer.py` - анализатор кошельков
- `db.py` - база данных
- `notify.py` - Telegram уведомления
- `api_scraper.py` - скрапер API
- `hashdive_client.py` - HashDive API клиент
- `hashdive_whale_finder.py` - поиск китов
- `maintain_wallets.py` - обслуживание базы
- `daily_wallet_collection.sh` - ежедневный сбор
- `requirements.txt` - зависимости
- `.env` - конфигурация (Telegram токены)

## 🎯 Настройки бота

Текущие критерии (в коде):
- **Min Win Rate**: 75%
- **Min Consensus**: 3+ кошельков
- **Min Trades**: 10+
- **Daily Frequency**: ≤100
- **Check Interval**: каждые 7 секунд

## 🔄 Автоматические функции

1. **Автозапуск**: Бот запускается автоматически при перезагрузке сервера
2. **Автовосстановление**: Автоматически перезапускается при падении (через 10 сек)
3. **Ежедневная очистка**: Каждый день в 2:00 проверяет win rate и удаляет <75%
4. **Поиск китов**: Ежедневно ищет новых китов через HashDive API

## ✅ Проверка работы

После деплоя проверить:
1. Сервис запущен: `sudo systemctl status polymarket-bot`
2. Нет ошибок: `sudo journalctl -u polymarket-bot --no-pager | tail -50`
3. Пришел тестовый сигнал в Telegram
4. База кошельков растет

---

**🎯 Бот будет работать 24/7 и отправлять сигналы при консенсусе 3+ кошельに見合う (75%+ WR)!**

