# Telegram Bot Setup Instructions

## 1. Create Telegram Bot

1. Open Telegram and search for @BotFather
2. Send `/newbot` command
3. Follow instructions to create your bot
4. Save the bot token (looks like: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

## 2. Get Chat ID

### Method 1: Using @userinfobot
1. Search for @userinfobot in Telegram
2. Start a conversation and send any message
3. The bot will reply with your user ID

### Method 2: Using your bot
1. Send a message to your bot
2. Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
3. Look for "chat":{"id": in the response

## 3. Configure .env file

Create a `.env` file in the project root with:

```env
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_CHAT_ID=-1001234567890

# Monitoring Configuration
POLL_INTERVAL_SEC=7
ALERT_WINDOW_MIN=15
MIN_CONSENSUS=2
MAX_WALLETS=200
MAX_PREDICTIONS=1000

# Database Configuration
DB_PATH=polymarket_notifier.db

# Wallet Analysis Queue Configuration
API_MAX_WORKERS=3
API_TIMEOUT_SEC=20
API_RETRY_MAX=6
API_RETRY_BASE=1.2
ANALYSIS_TTL_MIN=180
```

## 4. Test Configuration

Run the test script to verify everything works:

```bash
python test_bet_monitoring.py
```

## 5. Start Bot

```bash
python polymarket_notifier.py
```

## Features

The bot will now:
- Monitor your tracked wallets for new trades
- Detect when 2+ wallets make the same bet
- Send Telegram alerts with:
  - Market information
  - Outcome details
  - Wallet addresses
  - Total amount
  - Average price
  - Time window
  - Direct link to market

## Alert Example

```
🚨 MATCHING BET ALERT 🚨

📊 Market: Real Madrid vs Barcelona
🎯 Outcome: Real Madrid
💰 Total Amount: $15,420.50
📈 Avg Price: 0.650
👥 Wallets: 3 (0xed88d6...df3c4, 0x5bffcf...6ffbe)
⏰ Time Window: 45s

🔗 View Market
```
