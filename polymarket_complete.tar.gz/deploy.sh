#!/bin/bash

# Polymarket Notifier Bot - Server Deployment Script
# Run this script on your Ubuntu server to set up 24/7 monitoring

set -e

echo "🚀 Deploying Polymarket Notifier Bot to Server..."

# Update system packages
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python 3.12 and pip
echo "🐍 Installing Python 3.12..."
sudo apt install -y python3 python3-venv python3-dev python3-pip

# Install system dependencies
echo "🔧 Installing system dependencies..."
sudo apt install -y curl wget git build-essential

# Create application directory
echo "📁 Creating application directory..."
sudo mkdir -p /opt/polymarket-bot
sudo chown ubuntu:ubuntu /opt/polymarket-bot
cd /opt/polymarket-bot

# Copy application files (you'll need to upload these)
echo "📋 Please upload your bot files to /opt/polymarket-bot/"
echo "Required files:"
echo "  - polymarket_notifier.py"
echo "  - fetch_leaderboards_enhanced.py"
echo "  - db.py"
echo "  - notify.py"
echo "  - requirements.txt"
echo "  - .env (with your Telegram credentials)"

# Create Python virtual environment
echo "🔧 Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
echo "📦 Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Create systemd service file
echo "⚙️ Creating systemd service..."
sudo tee /etc/systemd/system/polymarket-bot.service > /dev/null <<EOF
[Unit]
Description=Polymarket Notifier Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/polymarket-bot
Environment=PATH=/opt/polymarket-bot/venv/bin
ExecStart=/opt/polymarket-bot/venv/bin/python polymarket_notifier.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable service
echo "🔄 Enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable polymarket-bot.service

# Create log rotation
echo "📝 Setting up log rotation..."
sudo tee /etc/logrotate.d/polymarket-bot > /dev/null <<EOF
/opt/polymarket-bot/polymarket_notifier.log {
    daily
    missingok
    rotate 7
    compress
    notifempty
    create 644 ubuntu ubuntu
}
EOF

echo "✅ Deployment complete!"
echo ""
echo "📋 Next steps:"
echo "1. Upload your bot files to /opt/polymarket-bot/"
echo "2. Make sure .env file has your Telegram credentials"
echo "3. Start the service: sudo systemctl start polymarket-bot"
echo "4. Check status: sudo systemctl status polymarket-bot"
echo "5. View logs: sudo journalctl -u polymarket-bot -f"
echo ""
echo "🔧 Service management commands:"
echo "  Start:   sudo systemctl start polymarket-bot"
echo "  Stop:    sudo systemctl stop polymarket-bot"
echo "  Restart: sudo systemctl restart polymarket-bot"
echo "  Status:  sudo systemctl status polymarket-bot"
echo "  Logs:    sudo journalctl -u polymarket-bot -f"
