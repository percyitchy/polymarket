"""
Telegram Notification Functions for Polymarket Notifier
Handles sending formatted alerts via Telegram Bot API
"""

import os
import requests
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class TelegramNotifier:
    def __init__(self, bot_token: Optional[str] = None, chat_id: Optional[str] = None):
        self.bot_token = bot_token or os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat_id = chat_id or os.getenv("TELEGRAM_CHAT_ID")
        
        if not self.bot_token or not self.chat_id:
            logger.warning("Telegram credentials not configured. Notifications will be printed to console.")
    
    def send_message(self, text: str, parse_mode: str = "HTML", 
                    disable_web_page_preview: bool = True) -> bool:
        """
        Send a message to Telegram
        
        Args:
            text: Message text
            parse_mode: HTML or Markdown
            disable_web_page_preview: Disable link previews
            
        Returns:
            True if successful, False otherwise
        """
        if not self.bot_token or not self.chat_id:
            logger.info(f"[TELEGRAM] Would send: {text}")
            return False
            
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": disable_web_page_preview
        }
        
        try:
            response = requests.post(url, json=payload, timeout=15)
            response.raise_for_status()
            logger.info("Telegram message sent successfully")
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to send Telegram message: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending Telegram message: {e}")
            return False
    
    def send_consensus_alert(self, condition_id: str, outcome_index: int, 
                           wallets: List[str], window_minutes: float = 10.0,
                           min_consensus: int = 3, alert_id: str = "") -> bool:
        """
        Send a consensus buy signal alert
        
        Args:
            condition_id: Market condition ID
            outcome_index: Outcome index being bought
            wallets: List of wallet addresses that bought
            window_minutes: Time window for consensus
            min_consensus: Minimum wallets required for alert
            alert_id: Unique alert identifier
            
        Returns:
            True if sent successfully
        """
        if len(wallets) < min_consensus:
            logger.warning(f"Not enough wallets for consensus: {len(wallets)} < {min_consensus}")
            return False
        
        # Format wallet list (show first 10, truncate if more)
        wallet_display = wallets[:10]
        wallets_bullet = '\n'.join([f"• <code>{w}</code>" for w in wallet_display])
        if len(wallets) > 10:
            wallets_bullet += f"\n• ... and {len(wallets) - 10} more"
        
        # Calculate consensus strength
        strength = self._calculate_consensus_strength(len(wallets), window_minutes)
        
        # Format market URL (Polymarket uses condition ID in URLs)
        market_url = f"https://polymarket.com/market/{condition_id[:8]}..."
        
        # Current timestamp
        timestamp_utc = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        
        # Build message
        message = f"""🔥 <b>Consensus Buy Signal</b>

<b>Market:</b> <code>{condition_id}</code>
<b>Outcome:</b> Index {outcome_index}
<b>Consensus:</b> {len(wallets)} wallets in {window_minutes:.0f}m (min {min_consensus})
<b>Strength:</b> {strength}

👛 <b>Top buyers</b>:
{wallets_bullet}

🔗 <b>Market</b>: {market_url}

<i>{timestamp_utc} UTC • alert id {alert_id}</i>"""
        
        return self.send_message(message)
    
    def send_startup_notification(self, wallet_count: int, tracked_count: int) -> bool:
        """Send startup notification with system status"""
        message = f"""🤖 <b>Polymarket Notifier Started</b>

📊 <b>System Status:</b>
• Total wallets in DB: {wallet_count}
• Actively tracked: {tracked_count}
• Monitoring: Active

<i>{datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")} UTC</i>"""
        
        return self.send_message(message)
    
    def send_error_notification(self, error_type: str, error_message: str) -> bool:
        """Send error notification"""
        message = f"""⚠️ <b>Polymarket Notifier Error</b>

<b>Type:</b> {error_type}
<b>Message:</b> <code>{error_message}</code>

<i>{datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")} UTC</i>"""
        
        return self.send_message(message)
    
    def send_heartbeat(self, stats: Dict[str, Any]) -> bool:
        """Send periodic heartbeat with statistics"""
        message = f"""💓 <b>Polymarket Notifier Heartbeat</b>

📊 <b>Current Stats:</b>
• Tracked wallets: {stats.get('tracked_wallets', 0)}
• Total wallets: {stats.get('total_wallets', 0)}
• High win rate (80%+): {stats.get('high_winrate', 0)}
• Medium win rate (70-80%): {stats.get('medium_winrate', 0)}
• Low win rate (<70%): {stats.get('low_winrate', 0)}

<i>{datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")} UTC</i>"""
        
        return self.send_message(message)
    
    def send_wallet_collection_summary(self, total_found: int, filtered_count: int, 
                                     criteria: Dict[str, Any]) -> bool:
        """Send summary of wallet collection process"""
        message = f"""📈 <b>Wallet Collection Complete</b>

📊 <b>Collection Results:</b>
• Wallets found: {total_found}
• Wallets meeting criteria: {filtered_count}
• Min trades: {criteria.get('min_trades', 50)}
• Min win rate: {criteria.get('min_win_rate', 0.65):.1%}
• Max daily frequency: {criteria.get('max_daily_freq', 10.0)}

<i>{datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")} UTC</i>"""
        
        return self.send_message(message)
    
    def _calculate_consensus_strength(self, wallet_count: int, window_minutes: float) -> str:
        """Calculate consensus strength based on wallet count and time window"""
        if wallet_count >= 10:
            return "🔥 Very Strong"
        elif wallet_count >= 7:
            return "⚡ Strong"
        elif wallet_count >= 5:
            return "📈 Moderate"
        elif wallet_count >= 3:
            return "👀 Weak"
        else:
            return "❓ Unknown"
    
    def test_connection(self) -> bool:
        """Test Telegram bot connection"""
        if not self.bot_token or not self.chat_id:
            logger.warning("Telegram credentials not configured")
            return False
        
        test_message = f"""🧪 <b>Telegram Connection Test</b>

This is a test message from Polymarket Notifier.

<i>{datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")} UTC</i>"""
        
        return self.send_message(test_message)

# Convenience functions for backward compatibility
def send_telegram(text: str) -> bool:
    """Legacy function for sending Telegram messages"""
    notifier = TelegramNotifier()
    return notifier.send_message(text)

def send_consensus_alert(condition_id: str, outcome_index: int, wallets: List[str], 
                        window_minutes: float = 10.0, min_consensus: int = 3) -> bool:
    """Legacy function for sending consensus alerts"""
    notifier = TelegramNotifier()
    return notifier.send_consensus_alert(condition_id, outcome_index, wallets, 
                                       window_minutes, min_consensus)

# Example usage and testing
if __name__ == "__main__":
    # Test notification system
    notifier = TelegramNotifier()
    
    # Test connection
    if notifier.test_connection():
        print("Telegram connection test successful")
        
        # Test consensus alert
        test_wallets = [
            "0x1234567890abcdef1234567890abcdef12345678",
            "0xabcdef1234567890abcdef1234567890abcdef12",
            "0x9876543210fedcba9876543210fedcba98765432"
        ]
        
        notifier.send_consensus_alert(
            condition_id="0x1234567890abcdef",
            outcome_index=0,
            wallets=test_wallets,
            alert_id="TEST123"
        )
        
        print("Test notifications sent")
    else:
        print("Telegram connection test failed - check credentials")
